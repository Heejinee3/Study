package com.study.springboot;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Member {
    private int index;
    private String username;
    private String password;
    private String phone;
    private String address;
    private LocalDate joindate;

}
