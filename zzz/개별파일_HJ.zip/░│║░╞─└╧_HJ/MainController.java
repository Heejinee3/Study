package com.study.springboot;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.time.LocalDate;

import java.util.ArrayList;


@Controller
public class MainController {

    private ArrayList<Member> memberRepository = new ArrayList<>(); // 모든 member가 담겨진 list
    private int index=0; // member의 가장 마지막 index

    // 요청 URL: localhost:8080 (2~9단까지 show)
    @RequestMapping("/")
    public String main(){
        return "redirect:/gugudan/2~9"; // localhost:8080/gugudan/2~9로 이동
    }

    // 요청 URL: localhost:8080/gugudan/2~5 (2~5단까지 show)
    // 또는
    // 요청 URL: localhost:8080/gugudan/3 (3단만 show)
    @RequestMapping("/gugudan/{value}")
    public String gugudan(@PathVariable("value") String value,Model model){

        /**************** gugudan *************/

        // value = "2~5" 또는 "3"
        String[] splitValue = value.split("~"); // value를 split ex) ["2","5"] 
        int start = Integer.parseInt(splitValue[0]); // 첫번째 값 ex) "2"
        int end = Integer.parseInt(splitValue[splitValue.length-1]); // 마지막 값 ex) "5"
        
        // head list 만들기
        // head = ["2단","3단","4단","5단"]
        ArrayList<String> head = new ArrayList<>();
        for (int i = start; i != end + 1; i++){
            head.add(i+"단");
        }

        // body list 만들기
        // body ["2x1=2","2x2=4",...,"2x9=18"]
        //      ...
        //      ["5x1=5","5x2=10",...,"5x9=45"]
        ArrayList<ArrayList<String>> body = new ArrayList<>();
        for (int i = start; i <= end; i++){ // i는 2,3,4,5
            ArrayList<String> bodyColumn= new ArrayList<>();
            for (int j = 1; j <= 9; j++){ // j는 1,2,3,...,9
                int result = i*j;
                bodyColumn.add(i+ "x" + j + "=" + result); // "ixj=result"
            }
            body.add(bodyColumn);
        }

        int[] zeroToEight = {0,1,2,3,4,5,6,7,8};
        // head와 body 넘기기
        model.addAttribute("head",head);
        model.addAttribute("body",body);
        model.addAttribute("zeroToEight",zeroToEight);

        return "gugudan"; // gugudan.html
    }

    /**************** member *************/
    // 요청 URL: localhost:8080/member (모든 member show)
    @RequestMapping("/member")
    public String member(){
        return "redirect:/member/all"; // localhost:8080/member/all로 이동
    }

    // 요청 URL: localhost:8080/member/all (모든 member show)
    // 또는
    // 요청 URL: localhost:8080/member/0 (index가 0인 member show, 없으면 error)
    // 또는
    // 요청 URL: localhost:8080/member/hong (username이 hong인 member show, 없으면 error)
    @RequestMapping("/member/{value}")
    public String select(@PathVariable("value") String value,HttpServletRequest request, Model model){
        // 요청 URL: localhost:8080/member/all 일 때
        if (value.equals("all")){
            model.addAttribute("member_arr",memberRepository); // 모은 member가 있는 list를 add
            model.addAttribute("selectCase",0); // 모든 member를 선택할 경우 selectCase = 0, 아니면 1
        }
        // 요청 URL: localhost:8080/member/0 일때
        else if (value.matches("-?\\d+")){ // value가 정수일때
            for (int i = 0; i < memberRepository.size(); i++){
                Member member = memberRepository.get(i);
                if  (Integer.parseInt(value) == member.getIndex()){ // input된 index와 member의 index가 같을 때,
                    model.addAttribute("member",member); // 해당 member를 add
                    break;
                }
            }
            model.addAttribute("selectCase",1); // 모든 member를 선택할 경우 selectCase = 0, 아니면 1
        }
        // 요청 URL: localhost:8080/member/hong 일때
        else{ // 그외
            for (int i = 0; i < memberRepository.size(); i++){
                Member member = memberRepository.get(i);
                if  (value.equals(member.getUsername())){ // input된 username과 member의 username가 같을 때,
                    model.addAttribute("member",member); // 해당 member를 add
                    break;
                }
            }
            model.addAttribute("selectCase",1); // 모든 member를 선택할 경우 selectCase = 0, 아니면 1
        }

        return "member_select"; // member_select.html
    }

    // 요청 URL: localhost:8080/member-insert-form
    // 또는
    // localhost:8080 에 들어가 insert 버튼 누르기
    @RequestMapping("/member-insert-form")
    public String insert_form(){
        return "member_insert"; // member_insert.html
    }
    @RequestMapping("/member-insert")
    public String insert(Member member,Model model,HttpServletRequest request){
        int pre_index = index;
        member.setIndex(index); // 가장 마지막 index를 member.index에 넣어준다. (member.index 세팅)
        index++;
        member.setJoindate(LocalDate.now()); // member.joindate 세팅
        memberRepository.add(member); // 새로운 member를 list에 넣기
        return "redirect:/member/" + pre_index; // localhost:8080/member/index 로 이동
    }

    // 요청 URL: localhost:8080/member-update-form
    // 또는
    // localhost:8080 에 들어가 update 버튼 누르기
    @RequestMapping("/member-update-form")
    public String update_form(){
        return "member_update"; // member_update.html
    }
    @RequestMapping("/member-update")
    public String update(Member member, Model model,HttpServletRequest request){
        String index_param = request.getParameter("index"); // input된 index 얻기
        for (int i = 0; i < memberRepository.size(); i++){
            Member pre_member = memberRepository.get(i); 
            if  (Integer.parseInt(index_param) == pre_member.getIndex()){ // member의 index와 input된 index가 같을 때
                member.setJoindate(pre_member.getJoindate()); // joindate가 null이 되지 않기 위해 그전 member의 joindate를 넣어줌
                memberRepository.set(i, member); // 새로운 member로 교체
                break;
            }
        }
        return "redirect:/member/" + index_param; //localhost:8080/member/index로 이동
    }

    // 요청 URL: localhost:8080/member-delete-form
    // 또는
    // localhost:8080 에 들어가 delete 버튼 누르기
    @RequestMapping("/member-delete-form")
    public String delete_form(){
        return "member_delete"; // member_delete.html
    }
    @RequestMapping("/member-delete")
    public String delete(Member member, Model model,HttpServletRequest request){
        int index_param = Integer.parseInt(request.getParameter("index")); // input된 index 받기, string->int로 변환
        memberRepository.removeIf(m -> index_param == m.getIndex()); // list에서 해당 index의 member 지우기
        return "redirect:/member/all"; // localhost:8080/member/all 로 이동
    }


}
