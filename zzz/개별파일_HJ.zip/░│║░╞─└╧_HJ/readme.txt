1.  java 파일은 java/com/study/springboot에 넣기
2.  html 파일은 resources/templates에 넣기
3.  구구단을 실행하려면 
    2단에서 90단: localhost:8080
    2단에서 5단 : localhost:8080/gugudan/2~5 
    2단만         : localhost:8080/gugudan/2
4. member관리를 실행하려면
    localhost:8080/member
    로 들어가 insert, update, delete 버튼 누르기
    예외처리를 안해서 없는 데이터를 update하거나 delete하면 에러날 수 있음.
    